package trafficmanagement;


import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.util.*;

public class TrafficManagementApp extends Application {
    TrafficSimulator simulator = new TrafficSimulator();
    VBox root = new VBox(15);
    VBox simulationBox = new VBox(10);
    Label statsLabel = new Label();
    Label graphLabel = new Label();
    Timeline timeline;
    int step = 0;

    @Override
    public void start(Stage primaryStage) {
        simulator.initialize();
        simulator.addInitialVehicles(10000); // Load 10,000 vehicles

        root.setPadding(new Insets(20));
        root.setStyle("-fx-background-color: #f0f8ff;");

        Label title = new Label("🛣️ Traffic Management Simulation (DSA CCP)");
        title.setFont(Font.font("Arial", 22));
        title.setTextFill(Color.DARKBLUE);

        Button startBtn = new Button("▶ Start Simulation");
        Button resetBtn = new Button("🔁 Reset Simulation");

        startBtn.setFont(Font.font("Arial", 16));
        resetBtn.setFont(Font.font("Arial", 16));

        startBtn.setOnAction(e -> startSimulation());
        resetBtn.setOnAction(e -> resetSimulation());

        HBox controlBox = new HBox(10, startBtn, resetBtn);
        controlBox.setPadding(new Insets(10));

        graphLabel.setText(simulator.getGraphSummary());
        graphLabel.setFont(Font.font("Consolas", 13));
        graphLabel.setTextFill(Color.DARKSLATEGRAY);

        root.getChildren().addAll(title, controlBox, graphLabel, simulationBox);

        Scene scene = new Scene(root, 1000, 750);
        primaryStage.setTitle("Efficient Traffic Simulator");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void startSimulation() {
        step = 0;
        simulator.totalCleared = 0;
        simulator.emergencyCleared = 0;
        updateView();

        timeline = new Timeline(new KeyFrame(Duration.seconds(1), event -> {
            step++;
            simulator.runSimulationStep();
            updateView();
        }));

        timeline.setCycleCount(20);
        timeline.play();
    }

    private void resetSimulation() {
        if (timeline != null) timeline.stop();
        simulator = new TrafficSimulator();
        simulator.initialize();
        simulator.addInitialVehicles(10000);
        simulationBox.getChildren().clear();
        graphLabel.setText(simulator.getGraphSummary());
        updateView();
    }

    private void updateView() {
        simulationBox.getChildren().clear();

        Label header = new Label("⏱️ Simulation Step: " + step);
        header.setFont(Font.font("Arial", 20));
        header.setTextFill(Color.DARKBLUE);
        simulationBox.getChildren().add(header);

        FlowPane cardFlow = new FlowPane(10, 10);
        cardFlow.setPadding(new Insets(10));
        simulationBox.getChildren().add(cardFlow);

        List<Intersection> sorted = new ArrayList<>(simulator.intersections.values());
        sorted.sort((a, b) ->
                (b.normalQueue.size() + b.priorityQueue.size()) -
                        (a.normalQueue.size() + a.priorityQueue.size())
        );

        for (int i = 0; i < Math.min(10, sorted.size()); i++) {
            Intersection inter = sorted.get(i);

            VBox card = new VBox(8);
            card.setPadding(new Insets(10));
            card.setPrefWidth(300);
            card.setStyle("-fx-border-color: #999; -fx-border-width: 2; " +
                    "-fx-background-color: #ffffff; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.1), 8, 0, 2, 2);");

            Label title = new Label("📍 Intersection: " + inter.name);
            title.setFont(Font.font("Arial", 16));
            title.setTextFill(Color.DARKSLATEBLUE);

            Label queue = new Label("🚗 Normal: " + inter.normalQueue.size() +
                    " | 🚨 Emergency: " + inter.priorityQueue.size());

            Label green = new Label("🟢 Green: " + inter.trafficLight.greenTime + "s");
            green.setTextFill(Color.GREEN);
            Label red = new Label("🔴 Red: " + inter.trafficLight.redTime + "s");
            red.setTextFill(Color.RED);

            Label lightStatus = new Label("Light Status: " + inter.trafficLight.getStatus());
            lightStatus.setFont(Font.font("Arial", 14));
            lightStatus.setTextFill(Color.DARKRED);

            Label lastCleared = new Label("Last Cleared: " + inter.getLastCleared());
            lastCleared.setTextFill(Color.GRAY);

            card.getChildren().addAll(title, queue, lightStatus, green, red, lastCleared);
            cardFlow.getChildren().add(card);
        }

        statsLabel.setText("📊 Cleared: " + simulator.getTotalCleared() +
                " | Emergency Cleared: " + simulator.getEmergencyCleared());
        statsLabel.setFont(Font.font("Arial", 16));
        statsLabel.setTextFill(Color.MAGENTA);
        simulationBox.getChildren().add(statsLabel);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
