
	package trafficmanagement;

	public class TrafficLight {
	    public int greenTime;
	    public int redTime;

	    public TrafficLight(int greenTime, int redTime) {
	        this.greenTime = greenTime;
	        this.redTime = redTime;
	    }

	    public void adjustTiming(int queueLength) {
	        greenTime = 30 + queueLength * 2;
	        redTime = 60 - queueLength * 2;
	        if (redTime < 10) redTime = 10;
	    }

	    public String getStatus() {
	        return greenTime > redTime ? "GREEN" : redTime > greenTime ? "RED" : "YELLOW";
	    }
	}

