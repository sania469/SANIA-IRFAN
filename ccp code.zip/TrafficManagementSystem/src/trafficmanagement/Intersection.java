package trafficmanagement;


import java.util.*;

public class Intersection {
    String name;
    Queue<Vehicle> normalQueue = new LinkedList<>();
    PriorityQueue<Vehicle> priorityQueue = new PriorityQueue<>();
    TrafficLight trafficLight;

    // ✅ Track the last cleared vehicle
    private String lastCleared = "None";

    public Intersection(String name) {
        this.name = name;
        this.trafficLight = new TrafficLight(30, 30);
    }

    public void addVehicle(Vehicle v) {
        if (v.isEmergency) {
            priorityQueue.add(v);
        } else {
            normalQueue.add(v);
        }
    }

    public Vehicle processVehicle() {
        if (!priorityQueue.isEmpty()) {
            return priorityQueue.poll();
        } else if (!normalQueue.isEmpty() && trafficLight.greenTime > 0) {
            return normalQueue.poll();
        }
        return null;
    }

    // ✅ Used by the simulator to store last cleared vehicle
    public void addToProcessed(Vehicle v) {
        lastCleared = v.id;
    }

    // ✅ Displayed in the UI
    public String getLastCleared() {
        return lastCleared;
    }

	public Object getAverageWaitTime() {
		// TODO Auto-generated method stub
		return null;
	}
}
