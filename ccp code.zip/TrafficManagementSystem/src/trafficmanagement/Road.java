package trafficmanagement;


public class Road {
    public String from;
    public String to;
    public int travelTime;
    public int vehicleCount = 0;

    public Road(String from, String to, int travelTime) {
        this.from = from;
        this.to = to;
        this.travelTime = travelTime;
    }

    public void incrementVehicleCount() {
        vehicleCount++;
    }

    public void resetVehicleCount() {
        vehicleCount = 0;
    }
}
